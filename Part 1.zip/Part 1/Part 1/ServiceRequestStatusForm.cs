﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Part_1
{
    public partial class ServiceRequestStatusForm : Form
    {
        private BinarySearchTree serviceRequests = new BinarySearchTree();

        public ServiceRequestStatusForm()
        {
            InitializeComponent();
            this.Load += ServiceRequestStatusForm_Load;
        }

        private void ServiceRequestStatusForm_Load(object sender, EventArgs e)
        {
            // Sample data
            serviceRequests.Insert(new ServiceRequest(1, "Fix broken pipe", "In Progress"));
            serviceRequests.Insert(new ServiceRequest(2, "Street light repair", "Completed"));
            serviceRequests.Insert(new ServiceRequest(3, "Pothole repair", "Pending"));
            serviceRequests.Insert(new ServiceRequest(4, "Repairing lights", "Pending"));

            PopulateDataGrid();
        }

        private void PopulateDataGrid()
        {
            var data = GetAllRequests(serviceRequests.Root);
            dataGridView1.DataSource = data;
        }

        private List<ServiceRequest> GetAllRequests(BSTNode node)
        {
            if (node == null)
                return new List<ServiceRequest>();

            var left = GetAllRequests(node.Left);
            var right = GetAllRequests(node.Right);

            left.Add(node.Data);
            left.AddRange(right);

            return left;
        }
        private void button2_Click(object sender, EventArgs e)
        {
            Form1 mainMenu = new Form1();
            mainMenu.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int requestID;
            if (int.TryParse(txtRequestID.Text, out requestID))
            {
                var result = serviceRequests.Search(requestID);
                if (result != null)
                {
                    MessageBox.Show($"Request ID: {result.RequestID}\nDescription: {result.Description}\nStatus: {result.Status}");
                }
                else
                {
                    MessageBox.Show("Service Request not found.");
                }
            }
            else
            {
                MessageBox.Show("Please enter a valid Request ID.");
            }
        }
    }
}
