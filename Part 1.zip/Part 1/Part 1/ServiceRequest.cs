﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Part_1
{
    public class ServiceRequest
    {
        public int RequestID { get; set; }
        public string Description { get; set; }
        public string Status { get; set; }

        public ServiceRequest(int requestID, string description, string status)
        {
            RequestID = requestID;
            Description = description;
            Status = status;
        }
    }
}
