﻿using System;
using System.Collections.Generic;

namespace Part_1
{
    internal class Issues
    {
        // Properties for Location, Category, and Description
        public string Location { get; set; }
        public string Category { get; set; }
        public string Description { get; set; }

        // A static list to hold all submitted issues
        public static List<Issues> AllIssues = new List<Issues>();

        // Constructor to initialize the issue details
        public Issues(string location, string category, string description)
        {
            Location = location;
            Category = category;
            Description = description;
        }

        // Method to save the issue
        public void SaveIssue()
        {
            // Add the issue to the static list
            AllIssues.Add(this);
        }

        // Override ToString to display issue details in the list
        public override string ToString()
        {
            return $"Location: {Location}, Category: {Category}, Description: {Description}";
        }
    }
}
