﻿using System;
using System.Windows.Forms;

namespace Part_1
{
    public partial class ReportView : Form
    {
        // Constructor
        public ReportView()
        {
            InitializeComponent();
        }

        // Method to set the data from ReportIssues (if needed for future functionality)
        public void SetReportData(string location, string category, string description)
        {
            // You can use this method if you want to pass individual data from ReportIssues
        }

        // Load the list of submitted issues when the form is displayed
        private void ReportView_Load(object sender, EventArgs e)
        {
            // Clear any existing items in the ListBox
            lstIssues.Items.Clear();

            // Load all issues from the Issues static list into the ListBox
            foreach (var issue in Issues.AllIssues)
            {
                lstIssues.Items.Add(issue.ToString());  // Display issue details in the ListBox
            }
        }

        // Button click event to go back to ReportIssues form
        private void button1_Click(object sender, EventArgs e)
        {
            ReportIssues reportIssues = new ReportIssues();
            reportIssues.Show();
            this.Hide();
        }

        // Button click event to go back to Main Menu (Form1)
        private void button2_Click(object sender, EventArgs e)
        {
            Form1 mainMenu = new Form1();
            mainMenu.Show();
            this.Hide();
        }
    }
}
