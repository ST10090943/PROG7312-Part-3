﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Part_1
{
    public class BinarySearchTree
    {
        public BSTNode Root { get; private set; }

        public void Insert(ServiceRequest data)
        {
            Root = InsertRec(Root, data);
        }

        private BSTNode InsertRec(BSTNode root, ServiceRequest data)
        {
            if (root == null)
            {
                root = new BSTNode(data);
                return root;
            }

            if (data.RequestID < root.Data.RequestID)
                root.Left = InsertRec(root.Left, data);
            else if (data.RequestID > root.Data.RequestID)
                root.Right = InsertRec(root.Right, data);

            return root;
        }

        public ServiceRequest Search(int requestID)
        {
            return SearchRec(Root, requestID)?.Data;
        }

        private BSTNode SearchRec(BSTNode root, int requestID)
        {
            if (root == null || root.Data.RequestID == requestID)
                return root;

            if (requestID < root.Data.RequestID)
                return SearchRec(root.Left, requestID);

            return SearchRec(root.Right, requestID);
        }
    }
}
