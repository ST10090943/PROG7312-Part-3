﻿using System;
using System.Drawing;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Part_1
{
    public partial class ReportIssues : Form
    {
        // Declare controls
        private TextBox txtLocation;
        private ComboBox cmbCategory;
        private RichTextBox rtbDescription;
        private Button btnAttachFile;
        private Button btnSubmit;
        private Label lblEngagement;
        private Button btnBackToMainMenu;

        // Constructor
        public ReportIssues()
        {
            InitializeComponent(); // Call InitializeComponent to set up form
        }

        // InitializeComponent method to set up controls
        private void InitializeComponent()
        {
            this.txtLocation = new System.Windows.Forms.TextBox();
            this.cmbCategory = new System.Windows.Forms.ComboBox();
            this.rtbDescription = new System.Windows.Forms.RichTextBox();
            this.btnAttachFile = new System.Windows.Forms.Button();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.lblEngagement = new System.Windows.Forms.Label();
            this.btnBackToMainMenu = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.progressBar1 = new System.Windows.Forms.ProgressBar(); // Initialize the ProgressBar
            this.SuspendLayout();
            // 
            // txtLocation
            // 
            this.txtLocation.ForeColor = System.Drawing.Color.Gray;
            this.txtLocation.Location = new System.Drawing.Point(20, 30);
            this.txtLocation.Name = "txtLocation";
            this.txtLocation.Size = new System.Drawing.Size(200, 22);
            this.txtLocation.TabIndex = 0;
            this.txtLocation.Text = "Enter the location of the issue";
            this.txtLocation.Enter += new System.EventHandler(this.TxtLocation_Enter);
            this.txtLocation.Leave += new System.EventHandler(this.TxtLocation_Leave);
            // 
            // cmbCategory
            // 
            this.cmbCategory.Items.AddRange(new object[] {
            "Sanitation",
            "Roads",
            "Utilities"});
            this.cmbCategory.Location = new System.Drawing.Point(20, 60);
            this.cmbCategory.Name = "cmbCategory";
            this.cmbCategory.Size = new System.Drawing.Size(200, 24);
            this.cmbCategory.TabIndex = 1;
            // 
            // rtbDescription
            // 
            this.rtbDescription.Location = new System.Drawing.Point(20, 90);
            this.rtbDescription.Name = "rtbDescription";
            this.rtbDescription.Size = new System.Drawing.Size(200, 80);
            this.rtbDescription.TabIndex = 2;
            this.rtbDescription.Text = "Enter a detailed description...";
            // 
            // btnAttachFile
            // 
            this.btnAttachFile.Location = new System.Drawing.Point(20, 180);
            this.btnAttachFile.Name = "btnAttachFile";
            this.btnAttachFile.Size = new System.Drawing.Size(100, 30);
            this.btnAttachFile.TabIndex = 3;
            this.btnAttachFile.Text = "Attach Media";
            this.btnAttachFile.Click += new System.EventHandler(this.BtnAttachFile_Click);
            // 
            // btnSubmit
            // 
            this.btnSubmit.Location = new System.Drawing.Point(20, 220);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(100, 30);
            this.btnSubmit.TabIndex = 4;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.Click += new System.EventHandler(this.BtnSubmit_Click);
            // 
            // btnBackToMainMenu
            // 
            this.btnBackToMainMenu.Location = new System.Drawing.Point(20, 300);
            this.btnBackToMainMenu.Name = "btnBackToMainMenu";
            this.btnBackToMainMenu.Size = new System.Drawing.Size(150, 30);
            this.btnBackToMainMenu.TabIndex = 6;
            this.btnBackToMainMenu.Text = "Back to Main Menu";
            this.btnBackToMainMenu.Click += new System.EventHandler(this.BtnBackToMainMenu_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(660, 13);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(112, 39);
            this.button1.TabIndex = 7;
            this.button1.Text = "ReportView";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // ReportIssues
            // 
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.ClientSize = new System.Drawing.Size(809, 386);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txtLocation);
            this.Controls.Add(this.cmbCategory);
            this.Controls.Add(this.rtbDescription);
            this.Controls.Add(this.btnAttachFile);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.lblEngagement);
            this.Controls.Add(this.btnBackToMainMenu);
            this.Name = "ReportIssues";
            this.Text = "Report Issues";
            this.ResumeLayout(false);
            this.PerformLayout();
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(20, 270);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(200, 23);
            this.progressBar1.Style = System.Windows.Forms.ProgressBarStyle.Marquee;
            this.progressBar1.Visible = false;  // Hide it initially until submit is pressed
            this.Controls.Add(this.progressBar1);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        // Placeholder text workaround for Location Input (Textbox)
        private void TxtLocation_Enter(object sender, EventArgs e)
        {
            if (txtLocation.Text == "Enter the location of the issue")
            {
                txtLocation.Text = "";
                txtLocation.ForeColor = Color.Black;
            }
        }

        private void TxtLocation_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtLocation.Text))
            {
                txtLocation.Text = "Enter the location of the issue";
                txtLocation.ForeColor = Color.Gray;
            }
        }

        // Button Click event to open file dialog for media attachment
        private void BtnAttachFile_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                ofd.Filter = "Images and Documents|*.jpg;*.jpeg;*.png;*.pdf;*.docx";
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    string filePath = ofd.FileName;
                    MessageBox.Show("File attached: " + filePath);
                }
            }
        }

        // Submit Button Click event
        private async void BtnSubmit_Click(object sender, EventArgs e)
        {
            // Show the ProgressBar
            progressBar1.Visible = true;

            // Simulate a delay (for example, representing data processing)
            await Task.Run(() =>
            {
                // Simulate a delay of 2 seconds (this is where you could put the real processing logic)
                System.Threading.Thread.Sleep(2000);
            });

            // Get the user input from the form
            string location = txtLocation.Text;
            string category = cmbCategory.SelectedItem?.ToString() ?? "No category selected";
            string description = rtbDescription.Text;

            // Create an instance of the Issues class with the user input
            Issues newIssue = new Issues(location, category, description);

            // Save the issue to the static list
            newIssue.SaveIssue();

            // Hide the ProgressBar after saving
            progressBar1.Visible = false;

            // Show a success message
            MessageBox.Show("Issue submitted successfully!");
        }



        // Back to Main Menu Button Click event
        private void BtnBackToMainMenu_Click(object sender, EventArgs e)
        {
            Form1 mainMenu = new Form1();
            mainMenu.Show();
            this.Close(); // Close current form after opening the main menu
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ReportView reportView = new ReportView();
            reportView.Show();
            this.Hide();
        }
    }
}
