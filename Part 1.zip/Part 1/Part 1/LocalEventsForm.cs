﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace Part_1
{
    public partial class LocalEventsForm : Form
    {
        // Data structures for events
        Stack<string> recentSearches = new Stack<string>();
        SortedDictionary<DateTime, List<Event>> eventDictionary = new SortedDictionary<DateTime, List<Event>>();
        HashSet<string> eventCategories = new HashSet<string>();

        public LocalEventsForm()
        {
            InitializeComponent();
            LoadEventCategories(); // Load categories into ComboBox
            LoadEvents();          // Load events into DataGridView
        }

        // Load predefined event categories
        private void LoadEventCategories()
        {
            eventCategories.Add("Community");
            eventCategories.Add("Charity");
            eventCategories.Add("Entertainment");
            eventCategories.Add("Sports");
            eventCategories.Add("Education");

            foreach (var category in eventCategories)
            {
                categoryComboBox.Items.Add(category);
            }
        }

        // Load hardcoded events into the event dictionary
        private void LoadEvents()
        {
            List<Event> eventsList = new List<Event>
            {
                new Event { Title = "Community Meetup", Category = "Community", Date = DateTime.Now.AddDays(2), UrgencyLevel = 1 },
                new Event { Title = "Charity Run", Category = "Charity", Date = DateTime.Now.AddDays(5), UrgencyLevel = 3 },
                new Event { Title = "Music Festival", Category = "Entertainment", Date = DateTime.Now.AddDays(7), UrgencyLevel = 2 },
                new Event { Title = "Football Match", Category = "Sports", Date = DateTime.Now.AddDays(10), UrgencyLevel = 1 },
                new Event { Title = "Education Workshop", Category = "Education", Date = DateTime.Now.AddDays(12), UrgencyLevel = 2 },
                new Event { Title = "Blood Donation Drive", Category = "Charity", Date = DateTime.Now.AddDays(14), UrgencyLevel = 2 },
                new Event { Title = "Book Fair", Category = "Community", Date = DateTime.Now.AddDays(15), UrgencyLevel = 3 },
                new Event { Title = "Career Expo", Category = "Education", Date = DateTime.Now.AddDays(18), UrgencyLevel = 1 }
            };

            foreach (var ev in eventsList)
            {
                if (!eventDictionary.ContainsKey(ev.Date))
                {
                    eventDictionary[ev.Date] = new List<Event>();
                }
                eventDictionary[ev.Date].Add(ev);
            }

            // Display all events initially
            eventDataGridView.DataSource = eventsList;
        }

        // Search events based on category and date range
        private void SearchEvents(string category, DateTime startDate, DateTime endDate)
        {
            var filteredEvents = eventDictionary
                .Where(entry => entry.Key >= startDate && entry.Key <= endDate) // Filter by date range
                .SelectMany(entry => entry.Value)
                .Where(e => e.Category == category)
                .ToList();

            eventDataGridView.DataSource = filteredEvents;

            // Store the search in the stack (most recent 10 searches)
            string searchString = $"{category} - {startDate.ToShortDateString()} to {endDate.ToShortDateString()}";
            if (recentSearches.Count >= 10)
            {
                recentSearches.Pop(); // Remove oldest search
            }
            recentSearches.Push(searchString);
        }

        // Recommend events based on most searched categories
        private void RecommendEvents()
        {
            // Use a Dictionary to count the frequency of searched categories
            Dictionary<string, int> categoryCount = new Dictionary<string, int>();

            foreach (var search in recentSearches)
            {
                var category = search.Split('-')[0].Trim();
                if (!categoryCount.ContainsKey(category))
                {
                    categoryCount[category] = 0;
                }
                categoryCount[category]++;
            }

            // Find the most frequently searched category
            var mostSearchedCategory = categoryCount.OrderByDescending(c => c.Value).FirstOrDefault().Key;

            // Recommend events from the most searched category
            var recommendedEvents = eventDictionary.Values
                .SelectMany(list => list)
                .Where(e => e.Category == mostSearchedCategory)
                .ToList();

            eventDataGridView.DataSource = recommendedEvents;
        }

        // Back button functionality
        private void backButton_Click(object sender, EventArgs e)
        {
            Form1 mainMenu = new Form1();
            mainMenu.Show();
            this.Close();
        }

        // Search button click event
        private void searchButton_Click(object sender, EventArgs e)
        {
            string selectedCategory = categoryComboBox.SelectedItem?.ToString();
            DateTime startDate = startDatePicker.Value;
            DateTime endDate = endDatePicker.Value;

            // Perform search based on selected category and date range
            if (!string.IsNullOrEmpty(selectedCategory))
            {
                SearchEvents(selectedCategory, startDate, endDate);
            }
            else
            {
                MessageBox.Show("Please select a category to search.");
            }
        }

        // Recommend button click event
        private void recommendButton_Click(object sender, EventArgs e)
        {
            if (recentSearches.Count > 0)
            {
                RecommendEvents();
            }
            else
            {
                MessageBox.Show("No recent searches to base recommendations on.");
            }
        }
    }

    // Event class representing each event
    public class Event
    {
        public string Title { get; set; }
        public string Category { get; set; }
        public DateTime Date { get; set; }
        public int UrgencyLevel { get; set; } // 1 = Extremely Urgent, 2 = Urgent, 3 = Not Urgent
    }
}
